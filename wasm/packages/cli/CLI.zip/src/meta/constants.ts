export const DEFAULT_META_DIR = '.droply';
export const DEFAULT_META_NAME = '__droply_meta.json';
export const DEFAULT_META_PATH = `${DEFAULT_META_DIR}/${DEFAULT_META_NAME}`;
export const RESERVED_DIR = '.droply';
export const META_SCHEMA_VERSION = '1.0';
